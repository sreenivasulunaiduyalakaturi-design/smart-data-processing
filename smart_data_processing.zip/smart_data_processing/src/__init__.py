"""Smart Data Processing package."""
